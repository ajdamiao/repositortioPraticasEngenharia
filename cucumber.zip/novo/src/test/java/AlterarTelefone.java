import model.Aluno;
import model.Telefone;
import repository.AlunoRepository;
import repository.ChaveExisteException;
import repository.ChaveInexisteException;

public class AlterarTelefone {
    @io.cucumber.java.en.Given("^o app deu inicio$")
    public void oAppIniciou() {
    }

    @io.cucumber.java.en.And("^chamado o metodo de alterar telefone$")
    public void chamadoOMetodoDeAlteracao() throws ChaveExisteException, ChaveInexisteException {
        Aluno aluno = new Aluno("Joao", 123232);
        AlunoRepository.getInstance().insertAluno(aluno);
        aluno.addFone(new Telefone(12, "434343", 'R', true, "Rato"));

        AlunoRepository.getInstance().updateAluno(aluno);

        assert (!(AlunoRepository.getInstance().buscaAlunoMatricula(123232).getFones().isEmpty()));
    }

    @io.cucumber.java.en.Then("^o telefone foi alterado$")
    public void telefoneSalvoNoRepository() {
    }
}
