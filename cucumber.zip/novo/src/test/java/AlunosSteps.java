import model.Aluno;
import repository.AlunoRepository;
import repository.ChaveExisteException;

public class AlunosSteps {
    @io.cucumber.java.en.Given("^o app iniciou$")
    public void oAppIniciou() {
    }

    @io.cucumber.java.en.And("^foi criado o Controller$")
    public void foiCriadoOController() {
        assert (2 > 1);
    }

    @io.cucumber.java.en.And("^chamado o metodo de criacao$")
    public void chamadoOMetodoDeCriacao() throws ChaveExisteException {
        Aluno aluno = new Aluno("Junior", 17544);
        AlunoRepository.getInstance().insertAluno(aluno);

        assert(AlunoRepository.getInstance().buscaTodos().contains(aluno));
    }

    @io.cucumber.java.en.Then("^o aluno foi salvo no repository$")
    public void oAlunoFoiSalvoNoRepository() {
    }
}
