import model.Aluno;
import repository.AlunoRepository;
import repository.ChaveExisteException;

public class ExluirSteps {
    @io.cucumber.java.en.Given("^inicio do app$")
    public void oAppIniciou() {
    }

    @io.cucumber.java.en.And("^controller criado$")
    public void foiCriadoOController() {
        assert (2 > 1);
    }

    @io.cucumber.java.en.And("^chamado o metodo de exclusao$")
    public void chamadoOMetodoDeExclusao() throws ChaveExisteException {
        Aluno aluno = new Aluno("Junior", 17544);
        AlunoRepository.getInstance().insertAluno(aluno);
        AlunoRepository.getInstance().deleteAluno(17544);


        assert (!AlunoRepository.getInstance().buscaTodos().contains(aluno));

    }

    @io.cucumber.java.en.Then("^o aluno foi excluido do repository$")
    public void oAlunoFoiExcluidoNoRepository() {
    }
}
