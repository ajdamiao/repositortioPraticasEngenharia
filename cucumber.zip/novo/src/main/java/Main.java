import controller.AlunoController;

public class Main {
    public static void main(String[] args) {
        System.out.println("aqui");
        AlunoController controller = new AlunoController();

        controller.createAluno("Antônio Junior",123456,51,"999999999",'R');
        controller.createAluno("Henrique Oliveira",23656,51,"999999999",'R');
        controller.createAluno("João Luiz Silva",12346,51,"999999999",'R');
        controller.createAluno("Rafael Ribeiro",123456,51,"999999999",'R');
        controller.listaAlunos();
    }
}
