package repository;

public class ChaveExisteException extends Exception{
}
