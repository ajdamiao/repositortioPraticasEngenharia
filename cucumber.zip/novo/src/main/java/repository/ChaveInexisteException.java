package repository;

public class ChaveInexisteException extends Exception{
}
